//Operator in JS
//Basic operators in JS are as follows:- +, -, /, *, %

//Addition Operator in JS
let pizza = 50;
let burger = 30;
let total = pizza + burger;
document.write(total);

//Substraction Operator in JS
let chicken = 100;
let fish = 50;
let fry = chicken - fish;
document.write(fry);

//Division Operator in JS
let mobile = 60;
let tab = 60;
let computer = mobile / tab;
document.write(computer);

//Multiplication Operator in JS
let hand = 10;
let leg = 20;
let body = hand * leg;
document.write(body);

//Modulas Operator in JS
let black = 50;
let red = 30;
let white = black % red;
document.write(white);

//Additional Operations using operator...

let number1 = 50;
number1 += 10;
document.write(number1);

let number2 = 50;
number2 -= 10;
document.write(number2);

let number3 = 50;
number3 /= 10;
document.write(number3);

let number4 = 50;
number4 *= 10;
document.write(number4);

let number5 = 50;
number5 %= 10;
document.write(number5);