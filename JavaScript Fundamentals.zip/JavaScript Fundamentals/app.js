let pizza = 1;
console.log(pizza);
const burger = 4;
console.log(burger);

var sandwich = 6;
console.log(sandwich);