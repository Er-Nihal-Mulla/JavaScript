//comparison Operator
// ==
// !=
// >greater than
// < less than
// >=greater than equal to
// <=less than equal to

// Examples

let pizza = 8;
document.write(pizza==8);

let burger = 10;
document.write(burger!=10);

let chicken = 15;
document.write(chicken>15);

let body = 20;
document.write(body<20);

let one = 100;
document.write(one >= 100);

let two = 5;
document.write(two <= 5);

// Let's do this with strings

let name = 'NeeL';
console.log(name == 'NeeL');

let s_burger = 'hello';
document.write(burger!='hello');

let s_chicken = 'bye';
document.write(chicken > 'bye');

let s_body = 'good';
document.write(body < 'good');

let s_one = 'nice';
document.write(one >= 'nice');

let s_two = 'envi';
document.write(two <= 'envi');