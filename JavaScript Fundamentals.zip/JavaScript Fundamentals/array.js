let selectorColors = ['red', 'blue'];
console.log(selectorColors);

//supose you want to display some elements from all of the element then 
let product = ['A', 'B', 'C'];
console.log(product[1]);

//Suppose is you want add one more element in arrray then
let coldDrink = ['Maza', 'Thumps Up'];
coldDrink[2] = 'Sprite'
console.log(coldDrink);