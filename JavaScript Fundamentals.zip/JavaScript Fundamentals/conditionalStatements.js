// if statement

let eligibleAge = 18;
if(eligibleAge>17)
{
	document.write("You Are eligible for licence");
}


// if else statement

let time = 10;
if(time > 9)
{
	document.write(" This is your sleeping time");
}
else
{
	document.write("This is your dinner time");
}


// More Examples

let programming_Language = ['Python', 'JS', 'JAVA', 'React'];
if(programming_Language > 2)
{
	document.write("You are eligible for this posotion...:)");
}
else
{
	document.write("you are not eligible for this position");
}