 let learn = " programming languages";
 let first = 'javascript';
 let second = 'dart';
 let third = 'python';
  //templates strings
  let all = `You have ${learn}`;
  document.write(all);


  let html = 
  `<p>you have to learn ${learn}</p>
  <ul>
  <li>${first}</li>
  <li>${second}</li>
  <li>${third}</li>
  </ul>`

document.body.innerHTML = html;