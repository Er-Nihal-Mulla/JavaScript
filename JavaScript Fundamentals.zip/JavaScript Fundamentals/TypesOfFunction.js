// Calculating  a value

function square(number){
   return number * number;
}
console.log(square(5)); //Here you can use this method also and you can use following method also...:)

// let number = square(5);
// console.log(number);