
let guy = {
    name:'Neel',
    age:'22'
};

//Dot Notation
guy.name;
console.log(guy.name);

//Bracket Notatiom

guy['name'];
console.log(name);

