//strings

let name = 'NeeL';
document.write(name);

//string-concatenation
let firstName = 'Neel';
let lastName = 'Techno Room';
let fullName = firstName + ' ' + lastName;
console.log(fullName);

let sentence = 'don\'t do this';
console.log(sentence[1]);
