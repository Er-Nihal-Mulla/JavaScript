			// DataTypes in JavasScript
	// There are three types of DataTypes which we store in the var

		//1. Number
1,2,3,4,10.5,-15;

		//2. String
these stores charactors like text number email address in ""  ''
let name = 'NeeL';
let name = "Techno Room";

	//3. Boolean
helps in making logics true/false

	//4. null
defines a variable with no value
let name = null;

	//5. undefined
variable that are not defined
let name;

	//6. objects
complex data structures:- array, dates, literal, functions, etc.

	//7. symbol
used with objects
