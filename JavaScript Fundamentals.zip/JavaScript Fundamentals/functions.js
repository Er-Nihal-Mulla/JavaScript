//function is an one of the fundamental building block is Javascript

function greet(name){
    console.log('Techno' + ' ' + name);
}
greet('Room');

//if you want to print two messages at the time then

function twoMessage(channel_name, youtube_name){
    console.log('Hello' + ' ' + channel_name + ' ' + youtube_name);
}

twoMessage('Techno', 'Room');
