const interestRate = 0.3;


document.write(interestRate);