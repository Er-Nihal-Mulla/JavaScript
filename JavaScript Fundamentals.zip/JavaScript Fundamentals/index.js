let name = 'Neel';
console.log(name);

//Cannot use reserve keywords
//should be meaningful
//cannot start with number
//cannot contain a space or hyphone(-)
//Are case sensitive